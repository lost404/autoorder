<?php if (!defined('THINK_PATH')) exit(); echo ($data["ao_register_username"]); ?></br>
<?php echo ($data["ao_register_password"]); ?></br>
<?php echo ($data["ao_register_email"]); ?></br>
<?php echo ($data["ao_register_qq"]); ?></br>
<?php echo ($data["ao_register_phone"]); ?></br>