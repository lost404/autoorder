<?php
    return array(
    'registerFormUsernameInfo' => 'Please input your username!',
    'registerFormPasswordInfo' => 'Please input your password!',
    'registerFormEmailInfo'    => 'Please input your email!',
    'registerFormQQInfo'    => 'Please input your QQ number!',
    'registerFormPhoneInfo'    => 'Please input your phone number',
    'registerFormVerifyInfo'    => 'Please input your verify code!'
);
?>