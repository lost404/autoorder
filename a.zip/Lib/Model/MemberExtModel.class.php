<?php
    class MemberExtModel extends Model{
        
    }
?>