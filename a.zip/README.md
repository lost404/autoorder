AutoOrder
=========
简介
----
这是一个免费的自动订单系统.

遵循Apache2协议发布.

未经许可不得用于商业用途.

作者:lost404.

邮箱:lost404@163.com.

个人网站:http://www.lost404.com.

项目主页:http://autoorder.lost404.com.

源码:http://www.github.com/lost404/autoorder.
