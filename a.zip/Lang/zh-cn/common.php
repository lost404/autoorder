<?php
    return array(
        'falseTitle' => '错误信息',
        'trueTitle' => '正确信息',
    );
?>
