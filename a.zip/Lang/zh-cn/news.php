<?php
    return array(
        'noNews' => '没有此公告或者此公告已被删除！',
        'return' => '点此返回',
        'closeWindow' => '关闭当前公告',
        'otherNews' => '相关公告',
        'groupLimit' => '对不起，您无权限发布公告！'
    );
?>
