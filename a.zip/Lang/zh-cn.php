<?php
    return array(
        'ApiActionMemberRegisterVerifyError' => '您的验证码输入错误！请关闭此对话框返回刷新验证码并重新提交！'
    );
?>