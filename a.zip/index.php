<?php
    define('APP_DEBUG', true);
    
    require_once "./ThinkPHP/ThinkPHP.php";
?>